var x;
console.log(x);
console.log(typeof x);

var y = null;//null can be assigned as a value as a representation of no value
console.log(y);
console.log(typeof y);