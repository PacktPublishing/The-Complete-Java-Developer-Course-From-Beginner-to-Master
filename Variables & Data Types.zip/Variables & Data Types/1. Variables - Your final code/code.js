//declare a variable
var score;
console.log(score);

//declare a variable and initialize
var livesLeft = 3;
console.log(livesLeft);

//re-assign a value to our variable livesLeft
livesLeft = 2;
console.log(livesLeft);

//constants
const firstname = 'John';

