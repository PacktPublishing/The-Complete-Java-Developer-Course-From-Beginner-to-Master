var z = "1" + 5;
console.log(z);
console.log(typeof z);

z = "1" - 5;
console.log(z);
console.log(typeof z);

z = "one" * 2;
console.log(z);
console.log(typeof z);

z = 2 * null;
console.log(z);
console.log(typeof z);

console.log(0 == false);
console.log("" == false);
console.log(null == false);
console.log(undefined == false);

//undefined == null
console.log(undefined == null);
console.log(undefined == undefined);
console.log(null == null);

//NaN == NaN
console.log(NaN == NaN);
