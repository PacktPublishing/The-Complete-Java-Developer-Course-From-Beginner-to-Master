//Arrays Quick Overview
var shoppingList = ["bread", "eggs", "milk"];
console.log(shoppingList);
console.log(shoppingList[1]);
console.log(shoppingList.length);