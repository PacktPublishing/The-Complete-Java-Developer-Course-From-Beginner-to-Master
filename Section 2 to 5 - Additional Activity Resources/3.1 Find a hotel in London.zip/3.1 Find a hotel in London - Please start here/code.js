//create the hotel objects
var hotel1 = {
    name: "Forest view Hotel",
    price: 51,
    distance: 6.8
};
var hotel2 = {
    name: "OYO Abbey Hotel",
    price: 52,
    distance: 3.7
};
var hotel3 = {
    name: "Camden Belmont",
    price: 69,
    distance: 2.8
};
var hotel4 = {
    name: "St Athans Hotel",
    price: 74,
    distance: 1.2
};
var hotel5 = {
    name: "St Giles London",
    price: 139,
    distance: 0.7
};
var hotel6 = {
    name: "Ashburn Hotel",
    price: 153,
    distance: 2.6
};