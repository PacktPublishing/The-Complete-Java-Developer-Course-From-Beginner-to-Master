//show an alert message saying hi
window.alert('hi');

//print something in the console
console.log('Welcome to JS!');

var x = 1;