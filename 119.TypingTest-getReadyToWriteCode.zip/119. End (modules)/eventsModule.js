var eventsModule = (function(dModule, uModule, cModule, wModule){
    var addEventListeners = function(){

        //character typing event listener

        //click on download button event listener
        
        //click on restart button event listener

    };

                    
    return {
        //init function, initializes the test before start
        init: function(duration, textNumber){
            addEventListeners();
        }
    };
             
        
})(dataModule, UIModule, certificateModule, wordsModule);