var certificateModule = (function(){
    
    return {
        generateCertificate: function(){}
    };
})();