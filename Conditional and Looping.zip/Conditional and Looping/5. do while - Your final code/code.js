var x = 5;
do{
    console.log(x);
    x ++;
}while(x < 5)