//help the cashier return the right of change


//Programme input: 
    //Amount due
    //Amount paid by the customer

//Programme output:
    //Print change amount
    //Print change breakdown: notes and coins



//UK Example: 
    //Banknotes:
    //£50 - £20 - £10 - £5
    //Coins:
    //£2 - £1 - 50p - 20p - 10p - 5p - 2p - 1p

console.log((50-44.44).toFixed(2));
var x = prompt('message');





