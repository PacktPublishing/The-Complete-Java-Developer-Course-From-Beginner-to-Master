//PI
console.log(Math.PI);

var x = Math.random();
console.log(x);

x = Math.round(3.6);
console.log(x);

x = Math.floor(3.6);
console.log(x);

//square root
x = Math.sqrt(4);
console.log(x);

//cos
x = Math.cos(0);
console.log(x);