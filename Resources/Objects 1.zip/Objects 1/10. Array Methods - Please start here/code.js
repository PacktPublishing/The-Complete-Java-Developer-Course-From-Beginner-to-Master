var shoppingList = ['orange', 'apple', 'banana'];
console.log(shoppingList);
