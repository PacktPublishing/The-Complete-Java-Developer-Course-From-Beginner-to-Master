//1. try this
//var greet = "Hello";
//
//function greet(){
//    return 'Hi';
//}
//
//console.log(typeof greet);

//2. try this
var greet = "Hello";
var greet = function(){
    return 'Hi';
}
console.log(typeof greet);
