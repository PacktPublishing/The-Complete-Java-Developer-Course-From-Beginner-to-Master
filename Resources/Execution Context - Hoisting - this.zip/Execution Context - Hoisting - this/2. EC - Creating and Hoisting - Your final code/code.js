greet();
console.log(language);
//console.log(x);

var language = 'Javascript';
function greet(){
    console.log('Hi there!');
}