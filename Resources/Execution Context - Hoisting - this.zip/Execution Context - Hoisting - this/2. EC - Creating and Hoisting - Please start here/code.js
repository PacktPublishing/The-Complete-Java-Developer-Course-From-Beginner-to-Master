var language = 'Javascript';
function greet(){
    console.log('Hi there!');
}