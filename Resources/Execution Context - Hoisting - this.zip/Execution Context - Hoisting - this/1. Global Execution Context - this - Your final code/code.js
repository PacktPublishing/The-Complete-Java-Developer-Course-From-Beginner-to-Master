var language = 'Javascript';
function greet(){
    console.log('Hi there!');
}

console.log(window);

console.log(this);