var phone1 = {
    make: 'Apple',
    model: 'Iphone 7',
    warranty: 12,
    colour: 'black',
    extendWarranty: function(x){
        this.warranty += x;
    }
};
console.log(phone1);